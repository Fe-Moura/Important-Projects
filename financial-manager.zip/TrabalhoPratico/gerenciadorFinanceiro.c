#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct categorias{
    double dia;
    double mes;
    double ano;
};

void movimentacoes();
int main();

int resp(){
  int confirmacao;
  printf("\nDeseja ver outras categorias? (1. sim / 2. nao)");
  scanf("%d", &confirmacao);

  switch (confirmacao){
    case 1:
      movimentacoes();
      break;
    
    default:
      main();
      break;
  }
  return 0;
}

void movimentacoes(){
    int opcaoMovimentacoes;
    double gasto;

    printf("\n----------------\n");
    printf(" Movimentacoes\n");
    printf("----------------");
    

    printf("\n Categorias \n 1. Moradia \n 2. Trabalho \n 3. Estudos \n 4. Transporte \n 5. Alimentacao \n 6. Sair\n");
    scanf("%d", &opcaoMovimentacoes);


        if (opcaoMovimentacoes == 1){
            char categoria1[100] = "moradia";
            printf("digite seu gasto por dia na categoria (%s): \n", categoria1);
            scanf("%lf", &gasto);

            struct categorias moradia;
            moradia.dia = gasto;
            moradia.mes = moradia.dia*30;
            moradia.ano = moradia.mes*12;
            printf(" O SEU GASTO \n POR ANO: %.2lf \n POR MES: %.2lf \n POR DIA: %.2lf \n", moradia.ano, moradia.mes, moradia.dia);
            

            FILE* fptr = fopen("Moradia.html", "w+");
            int r;
	
            if(fptr == NULL){
                printf("Error: could not open 'Moradia.html'\n");
                //return EXIT_FAILURE;
            } 

            r = fputs("<!DOCTYPE html>\n", fptr);
            r = fputs("<html lang = 'en'>\n", fptr);
            r = fputs("<head>\n", fptr);
            r = fputs("<meta charset='UTF-8'>\n", fptr);
            r = fputs("<style type='text/css'>\n", fptr);
            r = fputs("table { background-color: lightblue; font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th{border: 2px solid #dddddd; text-align: center; padding: 10px;}\n", fptr);
            r = fputs("</style>\n", fptr);
            r = fputs("</head>\n", fptr);
            r = fputs("<body>\n", fptr);
            r = fputs("<table>\n", fptr);
            r = fputs("<tr>\n", fptr);
            r = fputs("<th>Categoria:</th>\n", fptr);
            r = fputs("<th>Gasto/dia</th>\n", fptr);
            r = fputs("<th>Gasto/mês</th>\n", fptr);
            r = fputs("<th>Gasto/ano</th>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("<tr>\n", fptr);
            char *htmlMor = (char*)malloc(500 * sizeof(char));

            sprintf(htmlMor, "<td>Moradia</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n", moradia.dia, moradia.mes, moradia.ano);
            r = fputs("</tr>\n", fptr);

            r = fputs(htmlMor, fptr);

            r = fputs("<tr>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("</table>\n", fptr);
            r = fputs("</body>\n", fptr);
            r = fputs("</html>\n", fptr);

            fclose(fptr);

            resp();
        }

        else if (opcaoMovimentacoes == 2){
            char categoria2[100] = "trabalho";
            printf("digite seu gasto por dia na categoria (%s): \n", categoria2);
            scanf("%lf", &gasto);

            struct categorias trabalho;
            trabalho.dia = gasto;
            trabalho.mes = trabalho.dia*30;
            trabalho.ano = trabalho.mes*12;
            printf(" O SEU GASTO \n POR ANO: %.2lf \n POR MES: %.2lf \n POR DIA: %.2lf", trabalho.ano, trabalho.mes, trabalho.dia);
            
            FILE* fptr = fopen("Trabalho.html", "w+");
            int r;
	
            if(fptr == NULL){
                printf("Error: could not open 'Trabalho.html'\n");
                //return EXIT_FAILURE;
            } 

            r = fputs("<!DOCTYPE html>\n", fptr);
            r = fputs("<html lang = 'en'>\n", fptr);
            r = fputs("<head>\n", fptr);
            r = fputs("<meta charset='UTF-8'>\n", fptr);
            r = fputs("<style type='text/css'>\n", fptr);
            r = fputs("table { background-color: lightblue; font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th{border: 2px solid #dddddd; text-align: center; padding: 10px;}\n", fptr);
            r = fputs("</style>\n", fptr);
            r = fputs("</head>\n", fptr);
            r = fputs("<body>\n", fptr);
            r = fputs("<table>\n", fptr);
            r = fputs("<tr>\n", fptr);
            r = fputs("<th>Categoria:</th>\n", fptr);
            r = fputs("<th>Gasto/dia</th>\n", fptr);
            r = fputs("<th>Gasto/mês</th>\n", fptr);
            r = fputs("<th>Gasto/ano</th>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("<tr>\n", fptr);
            char *htmlTrab = (char*)malloc(500 * sizeof(char));

            sprintf(htmlTrab, "<td>Trabalho</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n", trabalho.dia, trabalho.mes, trabalho.ano);
            r = fputs("</tr>\n", fptr);

            r = fputs(htmlTrab, fptr);

            r = fputs("<tr>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("</table>\n", fptr);
            r = fputs("</body>\n", fptr);
            r = fputs("</html>\n", fptr);

            fclose(fptr);

            resp();
        }

        else if (opcaoMovimentacoes == 3){
            char categoria3[100] = "estudos";
            printf("digite seu gasto por dia na categoria (%s): \n", categoria3);
            scanf("%lf", &gasto);

            struct categorias estudos;
            estudos.dia = gasto;
            estudos.mes = estudos.dia*30;
            estudos.ano = estudos.mes*12;
            printf(" O SEU GASTO \n POR ANO: %.2lf \n POR MES: %.2lf \n POR DIA: %.2lf", estudos.ano, estudos.mes, estudos.dia);
            
            FILE* fptr = fopen("Estudos.html", "w+");
            int r;
	
            if(fptr == NULL){
                printf("Error: could not open 'Estudos.html'\n");
                //return EXIT_FAILURE;
            } 

            r = fputs("<!DOCTYPE html>\n", fptr);
            r = fputs("<html lang = 'en'>\n", fptr);
            r = fputs("<head>\n", fptr);
            r = fputs("<meta charset='UTF-8'>\n", fptr);
            r = fputs("<style type='text/css'>\n", fptr);
            r = fputs("table { background-color: lightblue; font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th{border: 2px solid #dddddd; text-align: center; padding: 10px;}\n", fptr);
            r = fputs("</style>\n", fptr);
            r = fputs("</head>\n", fptr);
            r = fputs("<body>\n", fptr);
            r = fputs("<table>\n", fptr);
            r = fputs("<tr>\n", fptr);
            r = fputs("<th>Categoria:</th>\n", fptr);
            r = fputs("<th>Gasto/dia</th>\n", fptr);
            r = fputs("<th>Gasto/mês</th>\n", fptr);
            r = fputs("<th>Gasto/ano</th>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("<tr>\n", fptr);
            char *htmlEst = (char*)malloc(500 * sizeof(char));

            sprintf(htmlEst, "<td>Estudos</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n", estudos.dia, estudos.mes, estudos.ano);
            r = fputs("</tr>\n", fptr);

            r = fputs(htmlEst, fptr);

            r = fputs("<tr>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("</table>\n", fptr);
            r = fputs("</body>\n", fptr);
            r = fputs("</html>\n", fptr);

            fclose(fptr);

            resp();
        }

        else if (opcaoMovimentacoes == 4){
            char categoria4[100] = "transporte";
            printf("digite seu gasto por dia na categoria (%s): \n", categoria4);
            scanf("%lf", &gasto);

            struct categorias transporte;
            transporte.dia = gasto;
            transporte.mes = transporte.dia*30;
            transporte.ano = transporte.mes*12;
            printf(" O SEU GASTO \n POR ANO: %.2lf \n POR MES: %.2lf \n POR DIA: %.2lf", transporte.ano, transporte.mes, transporte.dia);
            
            FILE* fptr = fopen("Transporte.html", "w+");
            int r;
	
            if(fptr == NULL){
                printf("Error: could not open 'Transporte.html'\n");
                //return EXIT_FAILURE;
            } 

            r = fputs("<!DOCTYPE html>\n", fptr);
            r = fputs("<html lang = 'en'>\n", fptr);
            r = fputs("<head>\n", fptr);
            r = fputs("<meta charset='UTF-8'>\n", fptr);
            r = fputs("<style type='text/css'>\n", fptr);
            r = fputs("table { background-color: lightblue; font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th{border: 2px solid #dddddd; text-align: center; padding: 10px;}\n", fptr);
            r = fputs("</style>\n", fptr);
            r = fputs("</head>\n", fptr);
            r = fputs("<body>\n", fptr);
            r = fputs("<table>\n", fptr);
            r = fputs("<tr>\n", fptr);
            r = fputs("<th>Categoria:</th>\n", fptr);
            r = fputs("<th>Gasto/dia</th>\n", fptr);
            r = fputs("<th>Gasto/mês</th>\n", fptr);
            r = fputs("<th>Gasto/ano</th>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("<tr>\n", fptr);
            char *htmlTrans = (char*)malloc(500 * sizeof(char));

            sprintf(htmlTrans, "<td>Transporte</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n", transporte.dia, transporte.mes, transporte.ano);
            r = fputs("</tr>\n", fptr);

            r = fputs(htmlTrans, fptr);

            r = fputs("<tr>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("</table>\n", fptr);
            r = fputs("</body>\n", fptr);
            r = fputs("</html>\n", fptr);

            fclose(fptr);

            resp();
        }

        else if (opcaoMovimentacoes == 5){
            char categoria5[100] = "alimentacao";
            printf("digite seu gasto por dia na categoria (%s): \n", categoria5);
            scanf("%lf", &gasto);

            struct categorias alimentacao;
            alimentacao.dia = gasto;
            alimentacao.mes = alimentacao.dia*30;
            alimentacao.ano = alimentacao.mes*12;
            printf(" O SEU GASTO \n POR ANO: %.2lf \n POR MES: %.2lf \n POR DIA: %.2lf", alimentacao.ano, alimentacao.mes, alimentacao.dia);
            
            FILE* fptr = fopen("Alimentacao.html", "w+");
            int r;
	
            if(fptr == NULL){
                printf("Error: could not open 'Alimentacao.html'\n");
                //return EXIT_FAILURE;
            } 

            r = fputs("<!DOCTYPE html>\n", fptr);
            r = fputs("<html lang = 'en'>\n", fptr);
            r = fputs("<head>\n", fptr);
            r = fputs("<meta charset='UTF-8'>\n", fptr);
            r = fputs("<style type='text/css'>\n", fptr);
            r = fputs("table { background-color: lightblue; font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th{border: 2px solid #dddddd; text-align: center; padding: 10px;}\n", fptr);
            r = fputs("</style>\n", fptr);
            r = fputs("</head>\n", fptr);
            r = fputs("<body>\n", fptr);
            r = fputs("<table>\n", fptr);
            r = fputs("<tr>\n", fptr);
            r = fputs("<th>Categoria:</th>\n", fptr);
            r = fputs("<th>Gasto/dia</th>\n", fptr);
            r = fputs("<th>Gasto/mês</th>\n", fptr);
            r = fputs("<th>Gasto/ano</th>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("<tr>\n", fptr);
            char *htmlAlim = (char*)malloc(500 * sizeof(char));

            sprintf(htmlAlim, "<td>Alimentacao</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n <td>R$:%.2f</td>\n", alimentacao.dia, alimentacao.mes, alimentacao.ano);
            r = fputs("</tr>\n", fptr);

            r = fputs(htmlAlim, fptr);

            r = fputs("<tr>\n", fptr);
            r = fputs("</tr>\n", fptr);
            r = fputs("</table>\n", fptr);
            r = fputs("</body>\n", fptr);
            r = fputs("</html>\n", fptr);

            fclose(fptr);

            resp();
        }

        else if (opcaoMovimentacoes == 6){
            main();
        }

        else{
            printf("Categoria Invalida. \n");
            return movimentacoes();
        }
}

void receitasGastos();
void confirmar(){
  int resp;
  printf("\nDeseja ver outras categorias? (1. sim / 2. nao)");
  scanf("%d", &resp);
  
  switch (resp){
    case 1:
      receitasGastos();
      break;
    
    default:
      main();
      break;
  }
}



void receitasGastos(){
    int opcaoGastos;
    double lista[] = {};
    int i = 0;
    float item;
    int dia;
    char descricao[250];
    char mes[250];
    int ano; 
    int r;

    puts("----------------");
    puts("Gastos e Receitas");
    puts("----------------");


    printf("Vamos comecar: \n");
    printf("Digite o dia do gasto: \n");
    scanf("%d", &dia);
    printf("Digite o mes do gasto: \n");
    scanf("%s", mes);
    printf("Digite a ano do gasto: \n");
    scanf("%d", &ano);
    printf("De uma breve descrição do gasto: \n");
    scanf("%s", descricao);
    printf("Digite o seu gasto: \n");
    scanf("%f", &item);
    lista[i] = item;
    printf("%.2f", lista[i]);

    FILE* fptr = fopen("Receitas.html", "w+");
	
	  if(fptr == NULL){
		  printf("Error: could not open 'Receitas.html'\n");
		  //return EXIT_FAILURE;
	  } 

    r = fputs("<!DOCTYPE html>\n", fptr);
    r = fputs("<html lang = 'en'>\n", fptr);
    r = fputs("<head>\n", fptr);
    r = fputs("<meta charset='UTF-8'>\n", fptr);
    r = fputs("<style type='text/css'>\n", fptr);
    r = fputs("table { background-color: gray; font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th{border: 2px solid #dddddd; text-align: center; padding: 10px;}\n", fptr);
    r = fputs("</style>\n", fptr);
    r = fputs("</head>\n", fptr);
    r = fputs("<body>\n", fptr);
    r = fputs("<table>\n", fptr);
    r = fputs("<tr>\n", fptr);
    r = fputs("<th>Breve descrição</th>\n", fptr);
    r = fputs("<th>Dia</th>\n", fptr);
    r = fputs("<th>Mês</th>\n", fptr);
    r = fputs("<th>Ano</th>\n", fptr);
    r = fputs("<th>Gasto</th>\n", fptr);
    r = fputs("</tr>\n", fptr);
    char *hello_world = (char*)malloc(500 * sizeof(char));

    sprintf(hello_world, "<td>%s</td>\n <td>%d</td>\n <td>%s</td>\n <td>%d</td>\n <td>%.2lf</td>", descricao, dia, mes, ano, item);
 
    r = fputs(hello_world, fptr);

    r = fputs("<tr>\n", fptr);
    r = fputs("</tr>\n", fptr);
    r = fputs("</table>\n", fptr);
    r = fputs("</body>\n", fptr);
    r = fputs("</html>\n", fptr);

	  fclose(fptr);
    confirmar();

}

int depositar(){
  float i;
  float resultado;

  printf("digite o valor que quer depositar: ");
  scanf("%f", &i);
  resultado += i;
  printf("\nSeu valor depositado foi de: %.2lf\n", i);
  printf("Seu valor na carteira atual é de: %.2lf\n", resultado);

  FILE* fptr = fopen("Deposito.html", "a");
	
	if(fptr == NULL){
	printf("Erro não foi possivel abrir 'Deposito.html'\n");
	return EXIT_FAILURE;
	} 
  
  fprintf(fptr, "Seu valor depositado foi de: %2.lf\n", i); 
  fprintf(fptr, "Seu valor na carteira atual é de: %.2lf\n", resultado);
  fclose(fptr);
  
  return main();
}

int retirar(){
  float n;
  float sub = 0;
  int a;
  int soma;

  printf("digite o valor que quer retirar: ");
  scanf("%f", &n);
  sub -=  n;
  printf("\nSeu valor retirado foi de: %.2lf\n", n);
  printf("Seu valor na carteira atual é de: %.2lf\n", sub);

  FILE* fptr = fopen("Retirada.html", "a");
	
	if(fptr == NULL){
	printf("Erro não foi possível abrir 'Retirada.html'\n");
	return EXIT_FAILURE;
	};
  
  fprintf(fptr, "Seu valor retirado foi de: %2.lf\n", n); 
  fprintf(fptr, "Seu valor na carteira atual é de: %.2lf\n", sub);
  fclose(fptr);  
  return main(); 
}


int teste(){
  FILE *fptr;
  fptr = fopen ("primeiro_arquivo.txt", "r"); 

  int resp;
  char caractere;
  
  if(caractere!=EOF){
       caractere = fgetc(fptr); 
      printf("%.2f", atof(&caractere)); 
      for (int i=0;i<4;i++){
        caractere = fgetc(fptr); 
        if (caractere==atoi("\n")){
          i++;
        }
         caractere = atof(&caractere);
      printf("%c\n", caractere);
      };
  };
};

int main(){
    int opcao;

    printf( "________________________________________\n"
            ".___  ___.  _______ .__   __.  __    __\n"  
            "|   \\/   | |   ____||  \\ |  | |  |  |  |\n" 
            "|  \\  /  | |  |__   |   \\|  | |  |  |  |\n" 
            "|  |\\/|  | |   __|  |  . `  | |  |  |  |\n"
            "|  |  |  | |  |____ |  |\\   | |  `--`  |\n" 
            "|__|  |__| |_______||__| \\__|  \\______/ \n"
            "________________________________________\n");
    printf("\n1. Receitas e Gastos\n2. Movimentacoes\n3. Depositar\n4. Retirar\n5. Encerrar\nO que deseja fazer hoje?");
    scanf("%d", &opcao);

    switch (opcao){
    case 1:
      receitasGastos();
      break;

    case 2:
      movimentacoes();
      break;

    case 3:
      depositar();
      break;

    case 4:
      retirar();
      break;    
    
    case 5:
      printf("\nAgradecemos a preferência.");
      break;

    case 6:
      return teste();
      break;

    default:
      printf("\nPOR FAVOR ESCOLHA UMA OPCAO VALIDA\n");
      main();
      break;
    }
  return 0;
} 

/*
arquivo.html ("r") //vai ler o arquivo
variavel = outra variavel
fprintf (ftpr, variavel)
arquivo.html ("w")
*/