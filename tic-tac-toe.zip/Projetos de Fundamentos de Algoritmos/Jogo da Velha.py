
################################################
##### PROGRAMADO POR: FELIPE MOURA PEREIRA #####
################################################

#importar funções do Sistema Operacional
import os.path

#Função para registrar um novo jogador no sistema; vitórias e derrotas = 0
def newPlayer():
    nome = input("Digite o nome do novo jogador: ")

#verifica se um arquivo para esse jogador já existe
    if os.path.isfile("{}.txt" .format(nome)):
        print ("Jogador já registrado!\n")
    else:
        print ("Registrando o jogador {}\n" .format(nome))
    f = open("{}.txt" .format(nome) , "w")
    f.write("0\n") #pontuação/vitórias
    f.write("0\n") #derrotas
    f.close()


#Função para excluir um jogador
def deletePlayer():
    nome = input ("Digite o nome do jogador a ser excluído: ")
#Verifica se o jogador a ser excluído existe
    if os.path.isfile("{}.txt" .format(nome)):
        print ("Excluindo o jogador {} \n" .format(nome))
        os.remove("{}.txt".format(nome))
    else:
        print ("Jogador {} não existe!\n" .format(nome))

#Função para ler a pontuação do jogador
def readPoints():
    nome = input("Digite o nome do jogador: ")
#Se o jogador existe, leia a sua pontuação
    if os.path.isfile("{}.txt" .format(nome)):
        f = open ("{}.txt" .format(nome), "r")
        print ("Pontuação de {}: " .format(nome))
        historico = f.readlines() #pego todas as linhas do arquivo para leitura
        vitorias = historico[0]
        derrotas = historico[1]
        print ("Vitórias: {}\n Derrotas: {}".format(vitorias,derrotas))
    else:
        print("Jogador {} não existe".format(nome))

def lost():
    nome = input ("Digite o nome do jogador perdedor:  ")
    f = open ("{}.txt".format(nome), "r")
    historico = f.readlines() #lê o arquivo
    f.close()
    vitorias = int(historico[0]) 
    derrotas = int(historico[1]) + 1
    f = open("{}.txt".format(nome), "w")
    f.write("{}\n{}". format(vitorias,derrotas))
    f.close()

#função para somar pontos
def win():
    nome = input ("Digite o nome do jogador vencedor:  ")
    f = open ("{}.txt".format(nome), "r")
    historico = f.readlines() #lê o arquivo
    f.close()
    vitorias = int(historico[0]) + 1
    derrotas = int(historico[1])
    f = open("{}.txt".format(nome), "w")
    f.write("{}\n{}". format(vitorias,derrotas))
    f.close()
    lost()



def start():
  nome1=input("Digite o nome do jogador 1: ")
   #verifica se um arquivo para esse jogador já existe
  if os.path.isfile("{}.txt".format(nome1)):
    print  ("{} entrou no jogo!\n".format(nome1))
  else:
    print ("{} não registrado!\n".format(nome1))
    return main()

  nome2=input("Digite o nome do jogador 2: ")
  #verifica se um arquivo para esse jogador já existe
  if os.path.isfile("{}.txt".format(nome2)):
    print  ("{} entrou no jogo!\n".format(nome2))
    pass
  else:
    print  ("{} não registrado!\n".format(nome2))
    return main()

#Cria o programa principal
def main():
    while True:
        print("---------Menu---------")
        print ("1 - Criar novo jogdor")
        print ("2 - Exibir pontuação")
        print ("3 - Excluir jogador")
        print ("4 - Iniciar")
        break
#crio uma variável para a escolha do menu
    opcao = input ("Escolha a opção desejada: ")
    
    if opcao == "1":
        newPlayer()
        return main()
    elif opcao == "2":
        readPoints()
        return main()
    elif opcao == "3":
        deletePlayer()
        return main()
    elif opcao =="4":
        start()
    else:
        print ("Opção inválida")
        return main()


#Execute o programa
main()

#Criando uma matriz
matriz = [
    [" "," "," "," "," "," "],
    [" "," "," "," "," "," "],
    [" "," "," "," "," "," "],
    [" "," "," "," "," "," "],
    [" "," "," "," "," "," "],
    [" "," "," "," "," "," "]
]


#Imprimindo o jogo para o usuário
def startGame():

    #Criando um looping para fazer jogadas consecutivas
    jogadas = 0
    while jogadas<=25:
        jogoVelha = """

        0    1   2   3   4
       _____________________ 
     0| {}  | {} | {} | {} | {}
      | ---+---+---+---+---
     1| {}  | {} | {} | {} | {}
      | ---+---+---+---+---
     2| {}  | {} | {} | {} | {}
      | ---+---+---+---+---
     3| {}  | {} | {} | {} | {}
      | ---+---+---+---+---
     4| {}  | {} | {} | {} | {}

        """.format(matriz[0][0], matriz[0][1], matriz[0][2], matriz[0][3], matriz[0][4],
        matriz[1][0], matriz[1][1], matriz[1][2], matriz[1][3], matriz[1][4],
        matriz[2][0], matriz[2][1], matriz[2][2], matriz[2][3], matriz[2][4], 
        matriz[3][0], matriz[3][1], matriz[3][2], matriz[3][3], matriz[3][4], 
        matriz[4][0], matriz[4][1], matriz[4][2], matriz[4][3], matriz[4][4])


        print(jogoVelha)
    
        #VERIFICA AS LINHAS (X)
        if matriz[4][4] == "X" and matriz[4][3] == "X" and matriz[4][2] == "X" and matriz[4][1] == "X" or matriz[4][0] == "X" and matriz[4][3] == "X" and matriz[4][2] == "X" and matriz[4][1] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()  
        if matriz[3][4] == "X" and matriz[3][3] == "X" and matriz[3][2] == "X" and matriz[3][1] == "X" or matriz[3][0] == "X" and matriz[3][3] == "X" and matriz[3][2] == "X" and matriz[3][1] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
    
        if matriz[2][4] == "X" and matriz[2][3] == "X" and matriz[2][2] == "X" and matriz[2][1] == "X" or matriz[2][0] == "X" and matriz[2][3] == "X" and matriz[2][2] == "X" and matriz[2][1] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        if matriz[1][4] == "X" and matriz[1][3] == "X" and matriz[1][2] == "X" and matriz[1][1] == "X" or matriz[1][0] == "X" and matriz[1][3] == "X" and matriz[1][2] == "X" and matriz[1][1] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        if matriz[0][4] == "X" and matriz[0][3] == "X" and matriz[0][2] == "X" and matriz[0][1] == "X" or matriz[0][0] == "X" and matriz[0][3] == "X" and matriz[0][2] == "X" and matriz[0][1] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()

        #VERIFICA AS LINHAS (O)
        if matriz[4][4] == "O" and matriz[4][3] == "O" and matriz[4][2] == "O" and matriz[4][1] == "O" or matriz[4][0] == "O" and matriz[4][3] == "O" and matriz[4][2] == "O" and matriz[4][1] == "O":
            print("Jogador 2 ganhou")   
            print (win())
            return main()
        if matriz[3][4] == "O" and matriz[3][3] == "O" and matriz[3][2] == "O" and matriz[3][1] == "O" or matriz[3][0] == "O" and matriz[3][3] == "O" and matriz[3][2] == "O" and matriz[3][1] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[2][4] == "O" and matriz[2][3] == "O" and matriz[2][2] == "O" and matriz[2][1] == "O" or matriz[2][0] == "O" and matriz[2][3] == "O" and matriz[2][2] == "O" and matriz[2][1] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[1][4] == "O" and matriz[1][3] == "O" and matriz[1][2] == "O" and matriz[1][1] == "O" or matriz[1][0] == "O" and matriz[1][3] == "O" and matriz[1][2] == "O" and matriz[1][1] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[0][4] == "O" and matriz[0][3] == "O" and matriz[0][2] == "O" and matriz[0][1] == "O" or matriz[0][0] == "O" and matriz[0][3] == "O" and matriz[0][2] == "O" and matriz[0][1] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()

        #VERIFICA AS COLUNAS (X)
        if matriz[0][0] == "X" and matriz[1][0] == "X" and matriz[2][0] == "X" and matriz[3][0] == "X" or matriz[4][0] == "X" and matriz[1][0] == "X" and matriz[2][0] == "X" and matriz[3][0] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()   
        if matriz[0][1] == "X" and matriz[1][1] == "X" and matriz[2][1] == "X" and matriz[3][1] == "X" or matriz[4][1] == "X" and matriz[1][1] == "X" and matriz[2][1] == "X" and matriz[3][1] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        if matriz[0][2] == "X" and matriz[1][2] == "X" and matriz[2][2] == "X" and matriz[3][2] == "X" or matriz[4][2] == "X" and matriz[1][2] == "X" and matriz[2][2] == "X" and matriz[3][2] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        if matriz[0][3] == "X" and matriz[1][3] == "X" and matriz[2][3] == "X" and matriz[3][3] == "X" or matriz[4][3] == "X" and matriz[1][3] == "X" and matriz[2][3] == "X" and matriz[3][3] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        if matriz[0][4] == "X" and matriz[1][4] == "X" and matriz[2][4] == "X" and matriz[3][4] == "X" or matriz[4][4] == "X" and matriz[1][4] == "X" and matriz[2][4] == "X" and matriz[3][4] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()

        #VERIFICA AS COLUNAS (O)
        if matriz[0][0] == "O" and matriz[1][0] == "O" and matriz[2][0] == "O" and matriz[3][0] == "O" or matriz[4][0] == "O" and matriz[1][0] == "O" and matriz[2][0] == "O" and matriz[3][0] == "O":
            print("Jogador 2 ganhou")   
            print (win())
            return main()
        if matriz[0][1] == "O" and matriz[1][1] == "O" and matriz[2][1] == "O" and matriz[3][1] == "O" or matriz[4][1] == "O" and matriz[1][1] == "O" and matriz[2][1] == "O" and matriz[3][1] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[0][2] == "O" and matriz[1][2] == "O" and matriz[2][2] == "O" and matriz[3][2] == "O" or matriz[4][2] == "O" and matriz[1][2] == "O" and matriz[2][2] == "O" and matriz[3][2] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[0][3] == "O" and matriz[1][3] == "O" and matriz[2][3] == "O" and matriz[3][3] == "O" or matriz[4][3] == "O" and matriz[1][3] == "O" and matriz[2][3] == "O" and matriz[3][3] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[0][4] == "O" and matriz[1][4] == "O" and matriz[2][4] == "O" and matriz[3][4] == "O" or matriz[4][4] == "O" and matriz[1][4] == "O" and matriz[2][4] == "O" and matriz[3][4] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        
        #VERIFICA AS DIAGONAIS (X)
        if matriz[1][0] == "X" and matriz[2][1] == "X" and matriz[3][2] == "X" and matriz[4][3] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        if matriz[0][0] == "X" and matriz[1][1] == "X" and matriz[2][2] == "X" and matriz[3][3] == "X" or matriz[4][4] == "X" and matriz[0][0] == "X" and matriz[1][1] == "X" and matriz[2][2] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        if matriz[0][1] == "X" and matriz[1][2] == "X" and matriz[2][3] == "X" and matriz[3][4] == "X":
            print("Jogador 1 ganhou")
            print (win())
            return main()
        
        #VERIFICA AS DIAGONAIS (O)
        if matriz[1][4] == "O" and matriz[2][3] == "O" and matriz[3][2] == "O" and matriz[4][1] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[0][4] == "O" and matriz[1][3] == "O" and matriz[2][2] == "O" and matriz[3][1] == "O" or matriz[4][0] == "O" and matriz[1][3] == "O" and matriz[2][2] == "O" and matriz[3][1] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()
        if matriz[0][3] == "O" and matriz[1][2] == "O" and matriz[2][1] == "O" and matriz[3][0] == "O":
            print("Jogador 2 ganhou")
            print (win())
            return main()

        #Definindo VELHA
        if jogadas == 25:
            print ("VELHA!!!")
            return main()



#Alternando entre  os turnos dos jogadores
        
        if (jogadas%2) == 0:
            print ("Turno do jogador 1 (X)")
        else:
            print ("Turno do jogador 2 (O)")
        
        #Define a posição do símbolo
        l = int(input("Digite a linha desejada:  "))
        c = int(input("Digite a coluna desejada:  "))

        while l > 4 or c > 4:
            print ("Linha e/ou Coluna inválida!")
            l = int(input("Digite a linha desejada:  "))
            c = int(input("Digite a coluna desejada:  "))

        #VERIFICA SE O ESPAÇO JÁ ESTÁ OCUPADO POR ALGUM SÍMBOLO (X ou O)
        while matriz [l][c] == "X":
            print()
            print ("Espaço ocupado!")
            print()
            l = int(input("Digite a linha desejada:  "))
            c = int(input("Digite a coluna desejada:  "))

        while matriz [l][c] == "O":
            print()
            print ("Espaço Ocupado!")
            print()
            l = int(input("Digite a linha desejada:  "))
            c = int(input("Digite a coluna desejada:  "))

        #inserir símbolos  para as jogadas ímpares e pares
        if (jogadas%2) == 0:
            matriz[l][c] = "X"
        else:
            matriz[l][c] = "O"

        #Soma as jogadas
        jogadas +=1
        
startGame()

