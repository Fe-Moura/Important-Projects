const express= require("express");
const bodyParser= require("body-parser");
const mongoose= require("mongoose")
const app= express();

app.set("view engine", "ejs");
app.set("views", "./views");

let postSchema= new mongoose.Schema({
    dbid: "string",
    dbnome: "string",
    dbmarca: "string",
    dbquantidade: "string"
});

let postModel= mongoose.model("posts", postSchema);

mongoose.connect("mongodb://localhost/LojaComputador");

app.use(express.static("./public"));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

app.get("/", function (req, resp){
        resp.render("produtos")
});

app.get("/adm", function (req, resp){
    postModel.find(function (err, objs){
        resp.render("formPost", {posts: objs})
    });
});



app.get("/QuemSomos", function (req, resp){
    resp.render("principal")
});

app.post("/adm", function (req, resp){
    let id= req.body.fid;
    let nome= req.body.fnome;
    let marca= req.body.fmarca;
    let quantidade= req.body.fquantidade;

    let novo= postModel({
        dbid: id,
        dbnome: nome,
        dbmarca: marca,
        dbquantidade: quantidade
    });
    novo.save();
    resp.render("mensagem", {mensagem: "Alterações realizadas com sucesso"})
});

app.post("/adm", function (req, resp){
    let id= req.body.fid;
    let nome= req.body.fnome;
    let marca= req.body.fmarca;
    let quantidade= req.body.fquantidade;

    let novo= postModel({
        dbid: id,
        dbnome: nome,
        dbmarca: marca,
        dbquantidade: quantidade
    });
    novo.save();
    novo.delete;
    resp.render("mensagem", {mensagem: "Alteraçõesss realizadas com sucesso"})
});



app.listen(8080,()=>{
    console.log('Servidor rodando...');
});


