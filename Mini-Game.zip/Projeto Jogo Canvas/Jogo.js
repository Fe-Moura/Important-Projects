const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");
const canvasWidth = canvas.width = 1250;
const canvasHeight = canvas.height = 500;
let gameSpeed = 10

const backgroundLayer1 = new Image();
backgroundLayer1.src = "https://cdn.discordapp.com/attachments/821867816739012612/841427376947986482/ee5cd3a734941cad181bb763ee686eb5.png";
const backgroundLayer2 = new Image();
backgroundLayer2.src = "https://cdn.discordapp.com/attachments/821867816739012612/841427376947986482/ee5cd3a734941cad181bb763ee686eb5.png";
const hidrante1 = new Image();
hidrante1.src = "https://media.discordapp.net/attachments/821867816739012612/842113921891565578/fire-hydrant-vector-id517593905.png"
const hidrante2 = new Image();
hidrante2.src = "https://media.discordapp.net/attachments/821867816739012612/842113921891565578/fire-hydrant-vector-id517593905.png"
const hidrante3 = new Image();
hidrante3.src = "https://media.discordapp.net/attachments/821867816739012612/842113921891565578/fire-hydrant-vector-id517593905.png"
const hidrante4 = new Image();
hidrante4.src = "https://media.discordapp.net/attachments/821867816739012612/842113921891565578/fire-hydrant-vector-id517593905.png"
const hidrante5 = new Image();
hidrante5.src = "https://media.discordapp.net/attachments/821867816739012612/842113921891565578/fire-hydrant-vector-id517593905.png"

const bandeira = new Image();
bandeira.src = "https://cdn.discordapp.com/attachments/821867816739012612/842225518710489098/mpKLkW19CD4AAAAASUVORK5CYII.png"

const band = {
    y: 100,
    x: 9000,
    speed: 4,
    height: 100,
    width: 400,

}





const img = new Image();
img.src = "https://media4.giphy.com/media/mDNCjHaiEPAuu1HMj1/200.gif";

let constant;
let by = 150;

let x = 0
let x2= 1250;


const doge = {
    y: 300,
    x: 50,
    speed: 5,
    height: 200,
    width: 200,
}
let gap = 85;

hidro1 = {
    y : 400,
    x :1050,
    speed: 10,
    height: 90,
    width: 90,
}

hidro2 = {
    y : 400,
    x :2000,
    speed: 8,
    height: 90,
    width: 90,
}


hidro3 = {
    y : 400,
    x :3800,
    speed: 6,
    height: 90,
    width: 90,
}

hidro4 = {
    y : 350,
    x :4400,
    speed: 4,
    height: 90,
    width: 90,
}

hidro5 = {
    y : 350,
    x :6200,
    speed: 4,
    height: 90,
    width: 90,
}


let tecla = [];
 /*
function desenhar() {
    ctx.drawImage(hidrante, 1100, 375, 75, 100);
    for (let i = 0; i < hidro.length; i++) {
        constant = hidrante.height + gap;
        ctx.drawImage(hidrante, hidro[i].x, hidro[i].y + constant);

        hidrante[i].x--;

        if (hidrante[i].x === 125) {
            hidrante.push({
                x: Math.floor(Math.random() * hidrante.height) - hidrante.height
            });
        }
    }
} */


function jump() {
    window.addEventListener("keydown", function (e) {
        tecla[e.keyCode] = true;
    });

    requestAnimationFrame(jump);
    //desenharDoge(img, doge.x, doge.y, doge.height, doge.width)
    if (tecla[32]) {
        doge.y -= 10;
        if (doge.y === 100) {
            down()

        }
    }
}

function down() {
    window.addEventListener("keydown", function (e) {
        tecla[e.keyCode] = true;
    });
    requestAnimationFrame(down);
    //desenharDoge(img, doge.x, doge.y, doge.height, doge.width)
    if (tecla[32]) {
        doge.y += 10;
        if (doge.y > 300) {
            doge.x = 50
            doge.y = 300
            jump()
            }
        }
    }


function animate() {
    ctx.clearRect(0, 0, canvasWidth, canvasHeight);
    ctx.drawImage(backgroundLayer1, x, 0, 1250, 500);
    ctx.drawImage(backgroundLayer2, x2, 0, 1250, 500);
    desenharDoge(img, doge.x, doge.y, doge.height, doge.width)
    if (x < -1250) x = 1250 + x2 - gameSpeed;
    else x -= gameSpeed;
    if (x2 < -1250) x2 = 1250 + x - gameSpeed;
    else x2 -= gameSpeed;
    requestAnimationFrame(animate);
}


function main() {

    animate()
    jump()
    hidrante6()
    hidrante7()
    hidrante8()
    hidrante9()
    hidrante10()
    bandeiras()

}



function desenharBandeira(foto, sX, sY, height, width) {
    ctx.drawImage(foto, sX, sY, height, width);
}

function desenharDoge(foto, sX, sY, height, width) {
    ctx.drawImage(foto, sX, sY, height, width);
}
function desenharHidro1(foto, sX, sY, height, width) {
    ctx.drawImage(foto, sX, sY, height, width);
}
function desenharHidro2(foto, sX, sY, height, width) {
    ctx.drawImage(foto, sX, sY, height, width);
}
function desenharHidro3(foto, sX, sY, height, width) {
    ctx.drawImage(foto, sX, sY, height, width);
}

function desenharHidro4(foto, sX, sY, height, width) {
    ctx.drawImage(foto, sX, sY, height, width);
}

function desenharHidro5(foto, sX, sY, height, width) {
    ctx.drawImage(foto, sX, sY, height, width);
}





function hidrante6 () {
    desenharHidro1(hidrante1,hidro1.x, hidro1.y, hidro1.height, hidro1.width)
    requestAnimationFrame(hidrante6);
 //   if (2<3){
        hidro1.x -= hidro1.speed
    //        }
        }

function hidrante7 () {
    desenharHidro2(hidrante2, hidro2.x, hidro2.y, hidro2.height, hidro2.width)
    requestAnimationFrame(hidrante7);
    //   if (2<3){
    hidro2.x -= hidro2.speed
    //        }
}

function hidrante8 () {
    desenharHidro3(hidrante3, hidro3.x, hidro3.y, hidro3.height, hidro3.width)
    requestAnimationFrame(hidrante8);
    //   if (2<3){
    hidro3.x -= hidro3.speed
    //        }
}

function hidrante9 () {
    desenharHidro4(hidrante4, hidro4.x, hidro4.y, hidro4.height, hidro4.width)
    requestAnimationFrame(hidrante9);
    //   if (2<3){
    hidro4.x -= hidro4.speed
    //        }
}

function hidrante10 () {
    desenharHidro5(hidrante5, hidro5.x, hidro5.y, hidro5.height, hidro5.width)
    requestAnimationFrame(hidrante10);
    //   if (2<3){
    hidro5.x -= hidro5.speed
    //        }
}

function bandeiras() {
    desenharBandeira(bandeira, band.x, band.y, band.height, band.width)
    requestAnimationFrame(bandeiras);
    //   if (2<3){
    band.x -= band.speed
    //        }
}

function won(){
       alert("win")
}
